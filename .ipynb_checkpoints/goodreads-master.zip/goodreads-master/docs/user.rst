user
=======

.. automodule:: goodreads.user
   :members:
   :undoc-members:
