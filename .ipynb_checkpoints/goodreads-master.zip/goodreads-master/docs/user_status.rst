user_status
===========

.. automodule:: goodreads.user_status
   :members:
   :undoc-members:
