session
====

.. automodule:: goodreads.session
   :members:
   :undoc-members:
