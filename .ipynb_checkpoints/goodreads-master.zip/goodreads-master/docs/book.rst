book
=======

.. automodule:: goodreads.book
   :members:
   :undoc-members:
