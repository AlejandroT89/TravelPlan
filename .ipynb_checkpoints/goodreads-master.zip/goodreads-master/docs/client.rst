client
======

.. automodule :: goodreads.client
   :members:
   :undoc-members:
