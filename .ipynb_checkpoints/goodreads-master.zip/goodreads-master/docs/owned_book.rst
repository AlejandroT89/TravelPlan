owned_book
==========

.. automodule:: goodreads.owned_book
   :members:
   :undoc-members:
